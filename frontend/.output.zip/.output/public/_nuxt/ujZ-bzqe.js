import{aq as t,J as e}from"./-_uPjKn3.js";const u=t((o,a)=>{if(!localStorage.getItem("authToken"))return e("/auth/login")});export{u as default};
