import{_ as t,c as o,o as r,J as c}from"./J8EY3PAs.js";const n={};function s(e,a){return r(),o("div",null,[c(e.$slots,"default")])}const _=t(n,[["render",s]]);export{_ as default};
