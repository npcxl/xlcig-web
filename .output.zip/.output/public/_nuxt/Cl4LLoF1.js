import{ar as t,q as e}from"./D6E0p70F.js";const u=t((o,a)=>{if(!localStorage.getItem("authToken"))return e("/auth/login")});export{u as default};
